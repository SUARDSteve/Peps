package com.example.pro3600_peps;

public class ModelFeed {

    private int id, postpic;
    private String name_event, name_orga, date, price;

    public ModelFeed(int id, String price, int postpic, String name_event, String name_orga, String date) {
        this.id = id;
        this.price = price;
        this.postpic = postpic;
        this.name_event = name_event;
        this.name_orga = name_orga;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getPostpic() {
        return postpic;
    }

    public void setPostpic(int postpic) {
        this.postpic = postpic;
    }

    public String getName_event() {
        return name_event;
    }

    public void setName_event(String name_event) {
        this.name_event = name_event;
    }

    public String getName_orga() {
        return name_orga;
    }

    public void setName_orga(String name_orga) {
        this.name_orga = name_orga;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
