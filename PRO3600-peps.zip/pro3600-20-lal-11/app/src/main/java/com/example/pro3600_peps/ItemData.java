package com.example.pro3600_peps;

class ItemData {

    int id;
    String date;
    String price;
    String nom_orga;
    String nom_event;
    int postpic;

    public ItemData(int id, String date, String price, String nom_orga, String nom_event, int postpic) {
        this.id = id;
        this.date = date;
        this.price = price;
        this.nom_orga = nom_orga;
        this.nom_event = nom_event;
        this.postpic = postpic;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getNom_orga() {
        return nom_orga;
    }

    public void setNom_orga(String nom_orga) {
        this.nom_orga = nom_orga;
    }

    public String getNom_event() {
        return nom_event;
    }

    public void setNom_event(String nom_event) {
        this.nom_event = nom_event;
    }

    public int getPostpic() {
        return postpic;
    }

    public void setPostpic(int postpic) {
        this.postpic = postpic;
    }
}
