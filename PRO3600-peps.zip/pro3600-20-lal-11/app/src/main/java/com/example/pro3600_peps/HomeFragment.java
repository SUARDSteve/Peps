package com.example.pro3600_peps;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;


public class HomeFragment extends Fragment {

    RecyclerView recyclerView;

 //   RecyclerView recyclerView;
 //   ArrayList<ModelFeed> modelFeedArrayList = new ArrayList<>();
 //   AdapterFeed adapterFeed;
 //   Activity mActivity;

//  @Override
//  public void onCreate(Bundle savedInstanceState) {
//      super.onCreate(savedInstanceState);
//      getActivity().setContentView(R.layout.fragment_home);
//
//      recyclerView = (RecyclerView) getView().findViewById(R.id.recyclerView);
//
//      RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
//      recyclerView.setLayoutManager(layoutManager);
//
//      adapterFeed = new AdapterFeed(getActivity(), modelFeedArrayList);
//      recyclerView.setAdapter(adapterFeed);
//
//      populateRecyclerView();
//  }

//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//
//        if (context instanceof Activity){
//            mActivity =(Activity) context;
//        }
//    }
//
//
//    @Override
//    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//
//        recyclerView = (RecyclerView) getView().findViewById(R.id.recyclerView);
//
//        //On a dû mettre getView. On ne doit utiliser getView dans un onViewCreated
//
//    }
//
//   @Nullable
//   @Override
//   public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//
//       super.onCreate(savedInstanceState);
//       //getActivity().setContentView(R.layout.fragment_home);
//
//       //recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
//
//       RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mActivity);
//       recyclerView.setLayoutManager(layoutManager);
//
//       adapterFeed = new AdapterFeed(mActivity, modelFeedArrayList);
//       recyclerView.setAdapter(adapterFeed);
//
//       populateRecyclerView();
//
//       return inflater.inflate(R.layout.fragment_home, container, false);
//   }
//
//    public void populateRecyclerView(){
//
//        ModelFeed modelFeed = new ModelFeed(1, "20", R.drawable.land1, "Soirée Médecine", "La FAC", "Samedi 10 avril");
//        modelFeedArrayList.add(modelFeed);
//        modelFeed = new ModelFeed(2, "10", R.drawable.land2, "Soirée Ingénieur", "TSP", "Samedi 17 avril");
//        modelFeedArrayList.add(modelFeed);
//        modelFeed = new ModelFeed(3, "50", R.drawable.land3, "Soirée Avocats", "Le tribunal", "Samedi 24 avril");
//        modelFeedArrayList.add(modelFeed);
//
//        adapterFeed.notifyDataSetChanged();
//
//    }

    public HomeFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = (RecyclerView) rootView.findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        ItemData itemData[] = {
          new ItemData(1,"29 mai 2020", "1", "La Cigale", "Spectale", R.drawable.land1),
          new ItemData(2,"15 juin 2020", "5", "Beez Event", "Soirée dansante", R.drawable.land2),
                new ItemData(3,"30 juillet 2020", "17", "Télécom SudParis", "Remise des diplômes", R.drawable.land3)
        };

        AdapterFeed2 myAdapter = new AdapterFeed2(itemData, getActivity());

        recyclerView.setAdapter(myAdapter);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        return rootView;
    }
}
