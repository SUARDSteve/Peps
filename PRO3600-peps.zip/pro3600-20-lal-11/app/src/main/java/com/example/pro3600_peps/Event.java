package com.example.pro3600_peps;

public class Event {

    private int id;
    private String name;
    private String organisateur;
    private String date;
    private String price;
    private int postPic;

    public Event(int id, String name, String organisateur, String date, String price, int postPic) {
        this.id = id;
        this.name = name;
        this.organisateur = organisateur;
        this.date = date;
        this.price = price;
        this.postPic = postPic;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrganisateur() {
        return organisateur;
    }

    public void setOrganisateur(String organisateur) {
        this.organisateur = organisateur;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getPostPic() {
        return postPic;
    }

    public void setPostPic(int postPic) {
        this.postPic = postPic;
    }
}
