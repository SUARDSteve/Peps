package com.example.pro3600_peps;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

public class AdapterFeed2 extends RecyclerView.Adapter<AdapterFeed2.ViewHolder> {

    private ItemData[] itemsData;
    RequestManager glide;
    Context context;

    public AdapterFeed2(ItemData[] itemsData, Context context) {

        this.itemsData = itemsData;
        this.context = context;
        glide = Glide.with(context);

    }

    // Create new views (invoked by the layout manager)
    @Override
    public AdapterFeed2.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_feed, null);

        // create ViewHolder

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);
        return viewHolder;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int position) {

        // - get data from your itemsData at this position
        // - replace the contents of the view with that itemsData

        viewHolder.tv_date.setText(itemsData[position].getDate());
        viewHolder.tv_name_orga.setText(String.valueOf(itemsData[position].getNom_orga()));
        viewHolder.tv_price.setText(itemsData[position].getPrice() + " €");
        viewHolder.tv_name_event.setText(String.valueOf(itemsData[position].getNom_event()));

        glide.load(itemsData[position].getPostpic()).into(viewHolder.imgView_postPic);


    }

    // inner class to hold a reference to each item of RecyclerView
    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tv_date, tv_name_event, tv_name_orga, tv_price;
        public ImageView imgView_postPic;

        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            imgView_postPic = (ImageView)itemView.findViewById(R.id.img_event);

            tv_date = (TextView) itemView.findViewById(R.id.tv_date);
            tv_name_event = (TextView) itemView.findViewById(R.id.tv_nom_evenement);
            tv_name_orga = (TextView) itemView.findViewById(R.id.tv_nom_organisateur);
            tv_price = (TextView) itemView.findViewById(R.id.tv_prix);
        }
    }

    // Return the size of your itemsData (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return itemsData.length;
    }

  }
