package com.example.pro3600_peps;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class AdapterFeed extends RecyclerView.Adapter<AdapterFeed.MyViewHolder> {

    Context context;
    ArrayList<ModelFeed> modelFeedArrayList = new ArrayList<>();
    RequestManager glide;

    public AdapterFeed(Context context, ArrayList<ModelFeed> modelFeedArrayList) {

        this.context = context;
        this.modelFeedArrayList = modelFeedArrayList;
        glide = Glide.with(context);

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_feed, parent, false);
        MyViewHolder viewHolder = new MyViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final ModelFeed modelFeed = modelFeedArrayList.get(position);

        holder.tv_date.setText(modelFeed.getDate());
        holder.tv_name_orga.setText(String.valueOf(modelFeed.getName_orga()));
        holder.tv_price.setText(modelFeed.getPrice() + " €");
        holder.tv_name_event.setText(String.valueOf(modelFeed.getName_event()));

        if(modelFeed.getPostpic()==0){
            holder.imgView_postPic.setVisibility(View.GONE);
        }else{
            holder.imgView_postPic.setVisibility(View.VISIBLE);
            glide.load(modelFeed.getPostpic()).into(holder.imgView_postPic);

        }

    }

    @Override
    public int getItemCount() {
        return modelFeedArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tv_date, tv_name_event, tv_name_orga, tv_price;
        ImageView imgView_postPic;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imgView_postPic = (ImageView)itemView.findViewById(R.id.img_event);

            tv_date = (TextView) itemView.findViewById(R.id.tv_date);
            tv_name_event = (TextView) itemView.findViewById(R.id.tv_nom_evenement);
            tv_name_orga = (TextView) itemView.findViewById(R.id.tv_nom_organisateur);
            tv_price = (TextView) itemView.findViewById(R.id.tv_prix);
        }


    }

}
